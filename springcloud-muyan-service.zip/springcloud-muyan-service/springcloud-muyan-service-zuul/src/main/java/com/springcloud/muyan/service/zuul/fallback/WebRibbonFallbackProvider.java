package com.springcloud.muyan.service.zuul.fallback;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.cloud.netflix.zuul.filters.route.FallbackProvider;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * @ClassName WebRibbonFallbackProvider
 * @Description
 * @Author muyan
 * @Date2019/1/3 17:35
 * @Version 1.0
 **/
@Component
public class WebRibbonFallbackProvider implements FallbackProvider {

    @Override
    public String getRoute() {
        return "springcloud-muyan-service-web-ribbom";
    }

    /**
     * 请求服务失败，则返回指定的信息给调用者
     * @param route
     * @param cause
     * @return
     */
    @Override
    public ClientHttpResponse fallbackResponse(String route, Throwable cause) {
        return new ClientHttpResponse(){
            @Override
            public HttpStatus getStatusCode() throws IOException {
                return HttpStatus.OK;
            }

            @Override
            public int getRawStatusCode() throws IOException {
                return HttpStatus.OK.value();
            }

            @Override
            public String getStatusText() throws IOException {
                return HttpStatus.OK.getReasonPhrase();
            }

            @Override
            public void close() {

            }

            @Override
            public InputStream getBody() throws IOException {
                ObjectMapper ob = new ObjectMapper(  );
                Map<String,Object> map = new HashMap<>(  );
                map.put( "status",200 );
                map.put( "message","网络异常，连接失败！" );
                return new ByteArrayInputStream(ob.writeValueAsString( map ).getBytes("UTF-8"));
            }

            @Override
            public HttpHeaders getHeaders() {
                HttpHeaders httpHeaders = new HttpHeaders();
                httpHeaders.setContentType( MediaType.APPLICATION_JSON_UTF8 );
                return httpHeaders;
            }
        };
    }
}
