package com.springcloud.muyan.service.web.ribbon.service;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.springcloud.muyan.service.web.ribbon.pojo.UserPojo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName RibbonServices
 * @Description
 * @Author muyan
 * @Date2018/12/29 15:53
 * @Version 1.0
 **/
@Service
public class RibbonServices {

    @Autowired
    private RestTemplate restTemplate;

    @HystrixCommand(fallbackMethod = "failGetName")
    public String getName(String name){
        System.out.println("name======" + name);
        return  restTemplate.getForObject("http://springcloud-muyan-service-provider/getName?name="+name,String.class);
    }


    @HystrixCommand(fallbackMethod = "failGetUser")
    public List<UserPojo> getUser(){
        return  restTemplate.getForObject( "http://springcloud-muyan-service-provider/getUser",List.class );
    }

    public List<UserPojo> failGetUser(){
        UserPojo userPojo = new UserPojo();
        List<UserPojo> list = new ArrayList<UserPojo>(  );
        System.out.println( "调用远程服务springcloud-muyan-service-provider失败，熔断getUser方法" );
        return list;
    }

    public String failGetName(){
        return "调用远程服务springcloud-muyan-service-provider失败，熔断getName方法";
    }
}
