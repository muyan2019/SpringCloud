package com.springcloud.muyan.service.web.ribbon.controller;

import com.springcloud.muyan.service.web.ribbon.pojo.UserPojo;
import com.springcloud.muyan.service.web.ribbon.service.RibbonServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @ClassName RibbonController
 * @Description
 * @Author muyan
 * @Date2018/12/29 15:50
 * @Version 1.0
 **/
@RestController
public class RibbonController {

    @Autowired
    private RibbonServices ribbonServices;

    @RequestMapping(value = "getName",method = RequestMethod.GET)
    public String getName(@RequestParam String name){
        return ribbonServices.getName(name);
    }

    @RequestMapping(value = "getUser",method = RequestMethod.GET,produces = {"application/json;charset=UTF-8"})
    public List<UserPojo> getUser(){
        return  ribbonServices.getUser();
    }


}
