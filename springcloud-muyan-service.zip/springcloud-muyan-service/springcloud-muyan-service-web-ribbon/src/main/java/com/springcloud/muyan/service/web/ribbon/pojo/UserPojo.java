package com.springcloud.muyan.service.web.ribbon.pojo;

import java.io.Serializable;

/**
 * @ClassName UserPojo
 * @Description
 * @Author muyan
 * @Date2019/1/3 15:57
 * @Version 1.0
 **/
public class UserPojo  implements Serializable {

    //id
    private int id;

    //用户名
    private String userName;
    //密码
    private String password;
    //年龄
    private int age;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "World[id="+id+",userName="+userName+",password="+password+",age="+age+"]";
    }
}
