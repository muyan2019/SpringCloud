package com.springcloud.muyan.service.service.impl;

import com.springcloud.muyan.service.dao.UserMapper;
import com.springcloud.muyan.service.pojo.UserPojo;
import com.springcloud.muyan.service.service.ProviderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @ClassName ProviderServiceImpl
 * @Description
 * @Author muyan
 * @Date2018/12/29 17:05
 * @Version 1.0
 **/
@Service
public class ProviderServiceImpl implements ProviderService {

    @Autowired
    private UserMapper userMapper;

    /**
     * 获取用户中所有的信息
     * @return
     */
    @Override
    @Cacheable(value="allUserInfo1")
    public List<UserPojo> getUser(){
//        System.out.println("开始查询.....");
//        try {
//            Thread.sleep(3 * 1000l);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        System.out.println("查询结束......");
        return userMapper.getUser();
    }


    /**
     * 新增一条用户信息到数据库中
     * @param userPojo
     * 说明：
     * 1：采用redis中的CacheEvict，新增一条数据之后，必须清除整个获取用户的redis缓存，这样保证数据每次都是最新的
     * 2：allEntries是否刷新所有的缓存，设置为false，不刷新所有，只刷新当前这一个缓存
     */
    @Override
    @Transactional
    @CacheEvict(value = "allUserInfo1" ,allEntries = true)
    public void insertUser(UserPojo userPojo) {
        System.out.println( "新增用户的信息为：username=" + userPojo.getUserName() + ",password=" + userPojo.getPassword() + ",age=" + userPojo.getAge() );
        userMapper.insertUser(userPojo);
    }
}
