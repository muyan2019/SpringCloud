package com.springcloud.muyan.service.service;

import com.springcloud.muyan.service.pojo.UserPojo;

import java.util.List;

/**
 * @InterfaceName ProviderService
 * @Description
 * @Author muyan
 * @Date2018/12/29 17:05
 * @Version 1.0
 **/
public interface ProviderService {

    //获取用户中所有的信息
    public List<UserPojo> getUser();

    //新增一条用户信息到数据库中
    public void insertUser(UserPojo userPojo);
}
