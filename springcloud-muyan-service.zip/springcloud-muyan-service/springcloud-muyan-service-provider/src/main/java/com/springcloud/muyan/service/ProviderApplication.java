package com.springcloud.muyan.service;

import com.alibaba.druid.pool.DruidDataSource;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import javax.sql.DataSource;

/**
 * @ClassName ProviderApplication
 * @Description
 * @Author muyan
 * @Date2018/12/29 15:09
 * @Version 1.0
 **/
@SpringBootApplication
@EnableEurekaClient
@ComponentScan("com.springcloud.muyan.service")
@MapperScan(value = {"classpath:config/*.xml","com.springcloud.muyan.service.dao"})
public class ProviderApplication {
    public static void main(String[] args) {
        SpringApplication.run(ProviderApplication.class,args);
    }

    @Bean
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSource druidDataSource(){
        DruidDataSource druidDataSource = new DruidDataSource();
        return  druidDataSource;
    }
}
