package com.springcloud.muyan.service.web.feign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * @ClassName WebFeignApplication
 * @Description
 * @Author muyan
 * @Date2018/12/29 16:35
 * @Version 1.0
 **/
@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
//添加熔断降级注解
@EnableCircuitBreaker
//开启熔断器仪表盘监控
@EnableHystrixDashboard
public class WebFeignApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebFeignApplication.class,args);
    }
}
