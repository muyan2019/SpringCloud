package com.springcloud.muyan.service.web.feign.services;

import com.springcloud.muyan.service.web.feign.pojo.UserPojo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * @InterfaceName FeignService
 * @Description
 * @Author muyan
 * @Date2018/12/29 16:39
 * @Version 1.0
 * fallback = FeignClientFallback.class，后面是你自定义的降级处理类，降级类一定要实现FeignService
 * 采用feign方法调用远程服务，必须编写一个接口，此接口声明需要调用远端服务的声明方法，
 * FeignClient中的value为调用远程服务的名称
 **/
@FeignClient(value = "springcloud-muyan-service-provider" ,fallback = FeignClientFallback.class)
public interface FeignService {

    @RequestMapping(value = "getName",method = RequestMethod.GET)
    public String getName(@RequestParam(value = "name") String name);

    @RequestMapping(value = "getUser",method = RequestMethod.GET)
    public List<UserPojo> getUser();

    @RequestMapping(value = "insertUser")
    public String insertUser(@RequestBody UserPojo userPojo);
}
