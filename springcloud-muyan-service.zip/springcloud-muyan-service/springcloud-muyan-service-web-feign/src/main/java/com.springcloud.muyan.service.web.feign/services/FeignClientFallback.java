package com.springcloud.muyan.service.web.feign.services;

import com.springcloud.muyan.service.web.feign.pojo.UserPojo;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * 针对调用远端服务，错降级处理
 * @ClassName FeignClientFallback
 * @Description
 * @Author muyan
 * @Date2019/1/2 19:05
 * @Version 1.0
 * 因为是对FeignService进行降级处理，所以必须实现目标的接口，符合面向接口变成规范
 **/
@Component
public class FeignClientFallback implements  FeignService{
    @Override
    public String getName(String name) {
        String message = "调用springcloud-muyan-service-provider服务失败，熔断getName方法";
        System.out.println( "调用springcloud-muyan-service-provider服务失败，熔断getName方法" );
        return message;
    }

    @Override
    public List<UserPojo> getUser() {
        System.out.println( "请求超时，熔断getUser方法" );
        UserPojo userPojo = new UserPojo();
        List<UserPojo> list = new ArrayList<UserPojo>(  );
        list.add( userPojo );
        return list;
    }

    @Override
    public String insertUser(UserPojo userPojo) {
        String message = "调用springcloud-muyan-service-provider服务失败，熔断insertUser方法";
        System.out.println( "调用springcloud-muyan-service-provider服务失败，熔断insertUser方法" );
        return message;
    }
}
