package com.springcloud.muyan.service.web.feign.config;

import com.netflix.hystrix.contrib.metrics.eventstream.HystrixMetricsStreamServlet;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @ClassName HystrixDashboardConfiguration
 * @Description
 * @Author muyan
 * @Date2019/1/3 10:40
 * @Version 1.0
 **/
@Configuration
public class HystrixDashboardConfiguration {

    /**
     * 因为此处springboot里面没有web.xml，所以此处采用代码注册一下servlet
     * servlet的名称是：HystrixMetricsStreamServlet
     * servlet的url为：hystrix.stream
     * @return
     */
    @Bean
    public ServletRegistrationBean getServlet(){
        HystrixMetricsStreamServlet hystrixMetricsStreamServlet = new HystrixMetricsStreamServlet();
        ServletRegistrationBean servletRegistrationBean = new ServletRegistrationBean( hystrixMetricsStreamServlet );
        servletRegistrationBean.setLoadOnStartup( 1 );
        servletRegistrationBean.addUrlMappings( "/hystrix.stream" );
        servletRegistrationBean.setName( "HystrixMetricsStreamServlet" );
        return  servletRegistrationBean;
    }
}
